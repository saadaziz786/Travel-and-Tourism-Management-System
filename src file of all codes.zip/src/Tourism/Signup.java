package Tourism;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.text.FontWeight;
import java.sql.*;

public class Signup extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Signup");
        primaryStage.setWidth(900);
        primaryStage.setHeight(500);

        // Left Panel
        VBox leftPanel = new VBox(10);
        leftPanel.setBackground(new Background(new BackgroundFill(Color.rgb(133, 193, 233), CornerRadii.EMPTY, Insets.EMPTY)));
        leftPanel.setAlignment(Pos.CENTER_LEFT);
        leftPanel.setPadding(new Insets(10));

        // Labels
        Label lblUsername = new Label("Username:");
        lblUsername.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));
        Label lblName = new Label("Name:");
        lblName.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));
        Label lblPassword = new Label("Password:");
        lblPassword.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));
        Label lblSecurity = new Label("Security Question:");
        lblSecurity.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));
        Label lblAnswer = new Label("Answer:");
        lblAnswer.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));

        // TextFields
        TextField tfUsername = new TextField();
        TextField tfName = new TextField();
        TextField tfPassword = new TextField();
        TextField tfAnswer = new TextField();

        // ChoiceBox
        ChoiceBox<String> security = new ChoiceBox<>();
        security.getItems().addAll("Fav Character from The Boys", "Fav Marvel superhero", "Your Lucky number", "Your childhood superhero");
        security.setValue("Fav Character from The Boys");

        // Buttons
        Button create = new Button("Create");
        create.setStyle("-fx-background-color: white; -fx-text-fill: rgb(133, 193, 233); -fx-font-weight: bold;");
        Button back = new Button("Back");
        back.setOnAction(event -> {
            new Login().start(primaryStage);
                });
        back.setStyle("-fx-background-color: white; -fx-text-fill: rgb(133, 193, 233); -fx-font-weight: bold;");
        create.setOnAction(event -> {
            String username = tfUsername.getText();
            String name = tfName.getText();
            String password = tfPassword.getText();
            String securityQuestion = security.getValue();
            String answer = tfAnswer.getText();
            String query = "insert into account values('"+username+"','"+name+"','"+password+"','"+securityQuestion+"','"+answer+"')";

            // Insert data into the database
            try  {
                Conn c = new Conn();
                c.s.executeUpdate(query);
                // Optionally, you can show a confirmation message or clear the input fields here
                System.out.println("Signup data inserted successfully.");
                showAlert(Alert.AlertType.INFORMATION, "Sign Up Successful", "User created successfully.");
                new Login().start(primaryStage);
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please choose another Username, This username already exists .");
                e.printStackTrace();
            }
        });

        // Adding components to left panel
        leftPanel.getChildren().addAll(lblUsername, tfUsername, lblName, tfName, lblPassword, tfPassword, lblSecurity, security, lblAnswer, tfAnswer, create, back);

        // Right Panel
        StackPane rightPanel = new StackPane();
        rightPanel.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));

        // Image
        Image image = new Image("icons/signup.png");
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(300);
        imageView.setFitHeight(300);
        rightPanel.getChildren().add(imageView);

        // Main Layout
        HBox mainLayout = new HBox(20);
        mainLayout.getChildren().addAll(leftPanel, rightPanel);

        // Set constraints on the left and right panels to prevent them from being resized beyond certain values
        HBox.setHgrow(leftPanel, Priority.ALWAYS);
        HBox.setHgrow(rightPanel, Priority.NEVER);

        // Scene
        Scene scene = new Scene(mainLayout);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
