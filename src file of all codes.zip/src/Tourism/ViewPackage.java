package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewPackage extends Application {
    String username;
    public ViewPackage(String username){
        this.username = username;
    }
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 850, 450);

        // Left pane with labels
        VBox leftPane = new VBox(15); // Increased vertical gap to 15
        leftPane.setPadding(new Insets(40, 20, 20, 20));
        leftPane.setStyle("-fx-background-color: blue;");

        Label lblName = new Label(" PACKAGE DETAILS");
        lblName.setStyle("-fx-font-size: 30; -fx-font-family: 'Yu Mincho'; -fx-text-fill: white;");

        Label lb1 = new Label("Username:");
        lb1.setStyle("-fx-text-fill: white;");

        Label lb2 = new Label("Package Type:");
        lb2.setStyle("-fx-text-fill: white;");

        Label lb3 = new Label("Number of Persons:");
        lb3.setStyle("-fx-text-fill: white;");

        Label lb4 = new Label("ID Type:");
        lb4.setStyle("-fx-text-fill: white;");

        Label lb5 = new Label("ID Number:");
        lb5.setStyle("-fx-text-fill: white;");

        Label lb6 = new Label("Phone:");
        lb6.setStyle("-fx-text-fill: white;");

        Label lb7 = new Label("Total Price:");
        lb7.setStyle("-fx-text-fill: white;");

        Conn c = new Conn();
        try{

            ResultSet resultSet = c.s.executeQuery("select * from bookPackage where username = '"+username+"'");
            while(resultSet.next()){
                lb1.setText("Username: " + resultSet.getString("username"));
                lb2.setText("Package Type: " + resultSet.getString("select_package"));
                lb3.setText("Total Persons " + resultSet.getString("TotalPersons"));
                lb4.setText("ID Type: " + resultSet.getString("idType"));
                lb5.setText("ID Number: " + resultSet.getString("IDNumber"));
                lb6.setText("Phone " + resultSet.getString("phone"));
                lb7.setText("Total Price: " + resultSet.getString("TotalPrice"));
            }

            resultSet.close();
        }catch(SQLException e){}
        // Add space at the bottom for the back button
        VBox.setVgrow(lb7, Priority.ALWAYS);

        leftPane.getChildren().addAll(lblName, lb1,  lb2,  lb3,  lb4,  lb5,  lb6,  lb7);

        // Back button
        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {

            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        VBox.setMargin(btnExit, new Insets(20, 0, 0, 0)); // Add margin at the top

        leftPane.getChildren().add(btnExit); // Add button to the left pane

        // Right pane with image
        StackPane rightPane = new StackPane();
        ImageView imageView = new ImageView(new Image("icons/bookedDetails.jpg"));
        imageView.setFitWidth(350);
        imageView.setFitHeight(350);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setTitle("View Package");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}