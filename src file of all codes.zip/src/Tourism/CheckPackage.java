package Tourism;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class CheckPackage extends Application {

    String username;
    Stage primaryStage; // Declare a variable to store the primary stage

    public CheckPackage(String username) {
        this.username = username;
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage; // Assign the primary stage to the class variable
        primaryStage.setTitle("Check Packages");

        TabPane tabPane = new TabPane();
        Tab tab1 = createTab("Package 1", new String[]{"package1.jpg", "GOLD PACKAGE", "6 days and 7 Nights", "Airport Assistance at Aiport", "Half Day City Tour", "Welcome drinks on Arrival", "Daily Buffet", "Full Day 3 Island Cruise", "English Speaking Guide", "BOOK NOW", "Summer Special", "Rs 32000 only"});
        Tab tab2 = createTab("Package 2", new String[]{"package2.jpg", "SILVER PACKAGE", "4 days and 3 Nights", "Toll Free and Entrance Free Tickets", "Meet and Greet at Aiport", "Welcome drinks on Arrival", "Night Safari", "Full Day 3 Island Cruise", "Cruise with Dinner", "BOOK NOW", "Winter Special", "Rs 25000 only"});
        Tab tab3 = createTab("Package 3", new String[]{"package3.jpg", "BRONZE PACKAGE", "6 days and 5 Nights", "Return Airfare", "Free Clubbing, Horse Riding & other Games", "Welcome drinks on Arrival", "Daily Buffet", "Stay in 5 Star Hotel", "BBQ Dinner", "BOOK NOW", "Winter Special", "Rs 12000 only"});

        tabPane.getTabs().addAll(tab1, tab2, tab3);

        Scene scene = new Scene(tabPane, 750, 480);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Tab createTab(String title, String[] pack) {
        Tab tab = new Tab(title);

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(16);
        gridPane.setPadding(new Insets(20));

        Label lblName = createLabel(pack[1], 20);
        Label l3 = createLabel(pack[2], 14);
        Label lblId = createLabel(pack[3], 14);
        Label l2 = createLabel(pack[4], 14);
        Label lblName_1 = createLabel(pack[5], 14);
        Label lblGender = createLabel(pack[6], 14);
        Label lblCountry = createLabel(pack[7], 14);
        Label lblReserveRoomNumber = createLabel(pack[8], 14);
        Label lblCheckInStatus = createLabel(pack[9], 16);
        Label lblDeposite = createLabel(pack[10], 20);
        Label la1 = createLabel(pack[11], 20);

        VBox textPane = new VBox(10, lblName, l3, lblId, l2, lblName_1, lblGender, lblCountry, lblReserveRoomNumber, lblCheckInStatus, lblDeposite, la1);
        textPane.setAlignment(Pos.CENTER_LEFT);

        ImageView imageView = new ImageView(new Image("icons/" + pack[0]));
        imageView.setFitWidth(400);
        imageView.setPreserveRatio(true);

        VBox imagePane = new VBox(imageView);
        imagePane.setAlignment(Pos.CENTER_RIGHT);

        Button backButton = new Button("Back");
        backButton.setOnAction(event -> {
            // Close the current stage
            primaryStage.close();
            // Open the dashboard
            new Dashboard(username).start(new Stage());
        });

        VBox buttonPane = new VBox(backButton);
        buttonPane.setAlignment(Pos.CENTER);

        gridPane.add(textPane, 0, 0);
        gridPane.add(imagePane, 1, 0);
        gridPane.add(buttonPane, 0, 1, 2, 1);

        tab.setContent(gridPane);
        return tab;
    }

    private Label createLabel(String text, double fontSize) {
        Label label = new Label(text);
        label.setFont(new javafx.scene.text.Font(fontSize));
        return label;
    }
}
