package Tourism;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Splash extends Application {
    @Override
    public void start(Stage primaryStage) {
        SplashFrame f1 = new SplashFrame();
        StackPane root = new StackPane(f1);
        primaryStage.setScene(new Scene(root, 1200, 600));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class SplashFrame extends ImageView {
    SplashFrame() {
        super(new Image("icons/splash.jpg"));
        setPreserveRatio(true);
        setFitWidth(1400);
        setFitHeight(750);
    }
}
