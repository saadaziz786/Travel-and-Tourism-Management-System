package Tourism;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.ResultSet;
import java.util.Random;

public class Review extends Application {

    private String username ;

    // Constructor to accept username
    public Review(String username) {
       this.username = username;
   }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Review");

        GridPane gridPane = createRegistrationFormPane();
        addUIControls(gridPane);

        Scene scene = new Scene(gridPane, 400, 400);
        // Set background color
        scene.setFill(Color.LIGHTBLUE);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createRegistrationFormPane() {
        GridPane gridPane = new GridPane();
        gridPane.setStyle("-fx-background-color: lightblue;");
        gridPane.setPadding(new Insets(15, 15, 15, 15));
        gridPane.setHgap(20);
        gridPane.setVgap(10);

        return gridPane;
    }

    private void addUIControls(GridPane gridPane) {
        // Add Header
        Label headerLabel = new Label("Review");
        headerLabel.setTextFill(Color.BLACK);
        headerLabel.setStyle("-fx-font-size: 30px;");
        gridPane.add(headerLabel, 0, 0, 2, 1);
        GridPane.setHalignment(headerLabel, HPos.LEFT);
        GridPane.setMargin(headerLabel, new Insets(20, 0, 20, 0));

        // Add Name Label
        Label nameLabel = new Label("User Name: " + username);
        gridPane.add(nameLabel, 0, 1);

        // Generate a random ReviewID
        Random random = new Random();
        int reviewID = random.nextInt(10000); // Assuming ReviewID is a 5-digit number
        Label reviewIDLabel = new Label("ReviewID: " + reviewID);
        gridPane.add(reviewIDLabel, 0, 2);

        // Add Select_package Label
        Label selectPackageLabel = new Label("Package/Hotel:");
        gridPane.add(selectPackageLabel, 0, 3);

        ComboBox<String> packageComboBox = new ComboBox<>();
        packageComboBox.getItems().addAll("Gold package", "Silver Package", "Bronze Package", "Taj Hotel", "Serena Hotel", "Luxus Hotel","Murree","Skardu","Gilgit");
        gridPane.add(packageComboBox, 1, 3);

        // Add Rating Label
        Label ratingLabel = new Label("Rating:");
        gridPane.add(ratingLabel, 0, 4);

        // Add Rating ComboBox
        ComboBox<String> ratingComboBox = new ComboBox<>();
        ratingComboBox.getItems().addAll("1", "2", "3", "4", "5");
        gridPane.add(ratingComboBox, 1, 4);

        // Add Submit Button
        Button submitButton = new Button("Submit Review");
        gridPane.add(submitButton, 0, 8, 2, 1);
        GridPane.setHalignment(submitButton, HPos.RIGHT);
        GridPane.setMargin(submitButton, new Insets(20, 0, 20, 0));

        submitButton.setOnAction(event -> {
            try {
                Conn c = new Conn();
                String query = "INSERT INTO Review (username, reviewid, hotel_package, rating) VALUES ('" + username + "', '" + reviewID + "', '" + packageComboBox.getValue() + "', '" + ratingComboBox.getValue() + "')";
                c.s.executeUpdate(query);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Review submitted successfully");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Unsuccessful", "Review submission failed");
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
