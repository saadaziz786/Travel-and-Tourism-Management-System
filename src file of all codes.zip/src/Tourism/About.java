package Tourism;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class About extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("About Tourism Management System");

        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 700, 450);

        // Create VBox for the left side
        VBox leftBox = new VBox(10);
        leftBox.setAlignment(Pos.CENTER_LEFT);

        Label titleLabel = new Label(" Tourism Management System");
        titleLabel.setStyle("-fx-text-fill: red; -fx-font-size: 20px;");

        Label contactLabel = new Label(" ");
        Label emailLabel = new Label("Feedback  Us through Email:");
        Hyperlink emailLink = new Hyperlink("saadaziz786786@gmail.com");
        emailLink.setOnAction(event -> {
            // Handle email review action
            System.out.println("Sending email...");
        });

        Label phoneLabel = new Label("Phone:");
        Label phoneNumLabel = new Label("03160830005");

        Label followLabel = new Label("Follow us on:");
        Hyperlink facebookLink = new Hyperlink("Facebook");
        facebookLink.setOnAction(event -> {
            // Handle Facebook link action
            System.out.println("Opening Facebook...");
        });
        Hyperlink twitterLink = new Hyperlink("Twitter");
        twitterLink.setOnAction(event -> {
            // Handle Twitter link action
            System.out.println("Opening Twitter...");
        });
        Hyperlink instagramLink = new Hyperlink("Instagram");
        instagramLink.setOnAction(event -> {
            // Handle Instagram link action
            System.out.println("Opening Instagram...");
        });

        Button exitButton = new Button("Exit");
        exitButton.setOnAction(event -> primaryStage.close());

        leftBox.getChildren().addAll(
                titleLabel,
                contactLabel,
                emailLabel,
                emailLink,
                phoneLabel,
                phoneNumLabel,
                followLabel,
                facebookLink,
                twitterLink,
                instagramLink,
                exitButton
        );

        // Create HBox for the right side
        HBox rightBox = new HBox();
        rightBox.setAlignment(Pos.CENTER);

        ImageView imageView = new ImageView("icons/review1.jpg");
        rightBox.getChildren().add(imageView);

        // Set left and right components in BorderPane
        root.setLeft(leftBox);
        root.setRight(rightBox);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
