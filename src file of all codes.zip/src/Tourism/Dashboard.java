package Tourism;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Dashboard extends Application {

    String username;
    public Dashboard(String username){
        this.username = username;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Travel Management System");

        // Left panel
        VBox leftPanel = new VBox();
        leftPanel.setStyle("-fx-background-color: #003366;");
        leftPanel.setPadding(new Insets(20));
        leftPanel.setSpacing(10);

        Text heading = new Text("Dashboard");
        heading.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
        heading.setFill(Color.WHITE);

        Button addPersonalDetails = createButton("Add Personal Details");
        addPersonalDetails.setOnAction(event -> {
            new AddCustomer(username).start(new Stage());
            primaryStage.close();
        });
        Button updatePersonalDetails = createButton("Update Personal Details");
        updatePersonalDetails.setOnAction(event -> {
            new UpdateDetails(username).start(new Stage());
            primaryStage.close();
        });
        Button viewPersonalDetails = createButton("View Personal Details");
        viewPersonalDetails.setOnAction(event -> {
            new ViewCustomer(username).start(new Stage());
            primaryStage.close();
        });
        Button deletePersonalDetails = createButton("Delete Personal Details");
        deletePersonalDetails.setOnAction(event -> {
            new DeleteCustomer(username).start(new Stage());
            primaryStage.close();
        });
        Button checkPackage = createButton("Check Package");
        checkPackage.setOnAction(event -> {
            new CheckPackage(username).start(new Stage());
            primaryStage.close();
        });
        Button bookPackage = createButton("Book Package");
        bookPackage.setOnAction(event -> {
            new BookPackage(username).start(new Stage());
            primaryStage.close();});
        Button viewPackage = createButton("View Package");
        viewPackage.setOnAction(event -> {
            new ViewPackage(username).start(new Stage());
            primaryStage.close();});
        Button viewHotels = createButton("View Hotels");
        viewHotels.setOnAction(event -> {
            new CheckHotel().start(new Stage());
            });
        Button bookHotel = createButton("Book Hotel");
        bookHotel.setOnAction(event -> {
            new HotelBook(username).start(new Stage());
            primaryStage.close();
        });
        Button viewBookedHotel = createButton("View Booked Hotel");
        viewBookedHotel.setOnAction(event -> {
            new CheckBookedHotel(username).start(new Stage());
            primaryStage.close();});
        Button destinations = createButton("Destinations");
        destinations.setOnAction(event -> {
            new Destinations().start(new Stage());
        });
        Button bookeddestination = createButton(" Book Destination");
        bookeddestination.setOnAction(event -> {
            new Destination(username).start(new Stage());
            primaryStage.close();
        });
        Button checkbookeddestination = createButton(" Check Booked Destination");
        checkbookeddestination.setOnAction(event -> {
            new BookedDestination(username).start(new Stage());
            primaryStage.close();
        });
        Button payments = createButton("Payments");
        payments.setOnAction(event -> {
            new Payment(username).start(new Stage());
            primaryStage.close();});
        Button calculators = createButton("Calculators");
        calculators.setOnAction(event ->{
        try{
            Runtime.getRuntime().exec("calc.exe");
        }catch(Exception e){ }});
        Button notepad = createButton("Notepad");
        notepad.setOnAction(event ->{
            try{
                Runtime.getRuntime().exec("notepad.exe");
            }catch(Exception e){ }});
        Button about = createButton("About");
        about.setOnAction(event -> {
            new About().start(new Stage());
            });
        Button review = createButton("Review");
        review.setOnAction(event -> {
            new Review(username).start(new Stage());
        });


        leftPanel.getChildren().addAll(
                heading, addPersonalDetails, updatePersonalDetails, viewPersonalDetails, deletePersonalDetails,
                checkPackage, bookPackage, viewPackage, viewHotels, bookHotel, viewBookedHotel,
                destinations,bookeddestination,checkbookeddestination, payments, calculators, notepad, about,review
        );

        // Right panel
        Image image = new Image("icons/home.jpg");
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(700);
        imageView.setFitHeight(800);
      //  imageView.setPreserveRatio(true);

        Text label = new Text("Tourism Management System");
        label.setFont(Font.font("Futura", FontWeight.BOLD, 40));
        label.setFill(Color.WHITE);

        VBox imageBox = new VBox(label, imageView);
        imageBox.setAlignment(Pos.CENTER);
        imageBox.setSpacing(7);

        VBox rightPanel = new VBox(imageBox);
        rightPanel.setStyle("-fx-background-color: #00FFFF; -fx-border-color: cyan; -fx-border-width: 3px;");
        rightPanel.setAlignment(Pos.CENTER);
        rightPanel.setPadding(new Insets(20));

        BorderPane root = new BorderPane();
        root.setLeft(leftPanel);
        root.setCenter(rightPanel);

        Scene scene = new Scene(root, 1000, 800);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createButton(String text) {
        Button button = new Button(text);
        button.setMinWidth(200);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setStyle("-fx-background-color: #003366; -fx-text-fill: white; -fx-border-color: white; -fx-border-width: 2px;");
        button.setOnAction(event -> System.out.println(text + " clicked"));
        return button;
    }

    public static void main(String[] args) {
        launch(args);

    }
}
