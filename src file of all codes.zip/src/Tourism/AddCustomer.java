package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import javax.management.Query;
import java.sql.ResultSet;

public class AddCustomer extends Application {
    private String username;

    // Constructor to accept username
    public AddCustomer(String username) {
        this.username = username;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Customer Full Bio-Data ");
        primaryStage.setWidth(1000);
        primaryStage.setHeight(700);

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");

        VBox leftPane = new VBox();
        leftPane.setAlignment(Pos.CENTER_LEFT);
        leftPane.setPadding(new Insets(20));
        leftPane.setSpacing(16);
        leftPane.setStyle("-fx-background-color: #85c1e9;");

        Label lblName = new Label("Customer Full Bio-Data Form");
        lblName.setFont(Font.font("Yu Mincho", 20));
        leftPane.getChildren().add(lblName);

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(16);

        gridPane.add(new Label("Name :"), 0, 0);
        gridPane.add(new Label("Username :"), 0, 1);
        gridPane.add(new Label("ID :"), 0, 2);
        gridPane.add(new Label("Number :"), 0, 3);
        gridPane.add(new Label("Gender :"), 0, 4);

        gridPane.add(new Label("Country :"), 0, 5);
        gridPane.add(new Label("Permanent Address :"), 0, 6);
        gridPane.add(new Label("Phone :"), 0, 7);
        gridPane.add(new Label("Email :"), 0, 8);

        TextField t2 = new TextField(); //Name
        TextField t7 = new TextField(); //Username
        TextField t1 = new TextField(); //Id card nmber
        TextField t3 = new TextField(); //country
        TextField t5 = new TextField(); //permanentAddress
        TextField t6 = new TextField(); //phone
        TextField t8 = new TextField(); //email

        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.getItems().addAll("Passport", "ID Card", "Employee ID", "Driving license");

        RadioButton maleRadioButton = new RadioButton("Male");
        RadioButton femaleRadioButton = new RadioButton("Female");

        ToggleGroup genderToggleGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(genderToggleGroup);
        femaleRadioButton.setToggleGroup(genderToggleGroup);


        VBox genderBox = new VBox(5, maleRadioButton, femaleRadioButton);
        gridPane.add(genderBox, 1, 4);

        gridPane.add(t2, 1, 0);
        gridPane.add(t7, 1, 1);
        gridPane.add(comboBox, 1, 2);
        gridPane.add(t1, 1, 3);
        gridPane.add(t3, 1, 5);
        gridPane.add(t5, 1, 6);
        gridPane.add(t6, 1, 7);
        gridPane.add(t8, 1, 8);

        leftPane.getChildren().add(gridPane);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        Button addButton = new Button("Add");
        //Query to enter Data into the database
        String gender = maleRadioButton.isSelected() ? "Female" : "Male";
     //   Toggle toggle = genderToggleGroup.getSelectedToggle();
    //    String gender = toggle == maleRadioButton ? "Male" : "Female";
        addButton.setOnAction(event -> {
            try{
                Conn c = new Conn();
                String s9 = t7.getText(); //username
                String s1 = comboBox.getValue();
                String s2 =  t1.getText();
                String s3 =  t2.getText();
                String s4 = gender;
                String s5 =  t3.getText();
                String s7 =  t5.getText();  //address
                String s8 =  t6.getText();
                String s10 = t8.getText(); //email

                String q1 = "insert into CustomerData values('"+s9+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s7+"','"+s8+"','"+s10+"')";
                c.s.executeUpdate(q1);
                System.out.println(q1);
                showAlert(Alert.AlertType.INFORMATION, "SuccessFull", "Data is inserted Successfully !");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "UnSuccessFull", "Please insert the the Data blanks !");

            }
        });
        addButton.setStyle("-fx-background-color: #000000; -fx-text-fill: #ffffff;");
        Button backButton = new Button("Back");
        backButton.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        // Query to insert the name and username

        try{
            Conn c = new Conn();
          String query =  "select * from account where username = '"+username+"'";
            ResultSet rs = c.s.executeQuery(query);
            System.out.println(query);
            while(rs.next()){
                t7.setText(rs.getString("username"));
                t2.setText(rs.getString("name"));
            }
        }catch(Exception e){
        };


        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: #ffffff;");
        addButton.setPrefWidth(100);
        backButton.setPrefWidth(100);
        buttonBox.getChildren().addAll(addButton, backButton);

        leftPane.getChildren().add(buttonBox);
        root.setLeft(leftPane);

        VBox rightPane = new VBox();
        rightPane.setAlignment(Pos.CENTER);
        rightPane.setPadding(new Insets(20));
        rightPane.setSpacing(10);

        Image image = new Image("icons/newcustomer.jpg"); // Update with your image path
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(400);
        imageView.setFitHeight(700);

        rightPane.getChildren().add(imageView);
        root.setRight(rightPane);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);

    }
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
