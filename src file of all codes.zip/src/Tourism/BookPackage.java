package Tourism;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.sql.*;

public class BookPackage extends Application {

    String username;
    public BookPackage(String username){
        this.username = username;
    }
    private TextField t1;
    private ChoiceBox<String> c1;
    private Label totalPriceLabel; // Initialize totalPriceLabel here
    private boolean priceChecked = false; // Track whether the price has been checked

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Book Package");

        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 800, 450);

        // Left pane with labels, text fields, and buttons
        VBox leftPane = new VBox(5); // Decreased vertical gap to 5
        leftPane.setPadding(new Insets(20));
        leftPane.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        Label lblName = new Label("BOOK PACKAGE");
        lblName.setStyle("-fx-font-size: 20; -fx-font-family: 'Yu Mincho';");
        Label la2 = new Label("Username :");
        Label lusername = new Label();
        lusername.setTextFill(Color.WHITE);
        Label lblId = new Label("Select Package :");
        Label la3 = new Label("Total Persons");
        Label lbl1 = new Label("ID Type:");
        Label l2 = new Label();
        l2.setTextFill(Color.WHITE);
        Label lbl2 = new Label("Number :");
        Label l3 = new Label();
        l3.setTextFill(Color.WHITE);
        Label lbl3 = new Label("Phone :");
        Label l4 = new Label();
        l4.setTextFill(Color.WHITE);
        Label lblDeposite = new Label("Total Price :");

        c1 = new ChoiceBox<>();
        c1.getItems().addAll("Gold Package", "Silver Package", "Bronze Package");
        c1.setValue("Gold Package");
        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from CustomerData where username = '"+username+"'");
            while(rs.next()){
                lusername.setText(rs.getString("username"));
                l2.setText(rs.getString("idtype"));
                l3.setText(rs.getString("IDNumber"));
                l4.setText(rs.getString("phone"));
            }
            rs.close();
        } catch(SQLException e){}

        t1 = new TextField();
        t1.setText("1"); // Default to one person

        totalPriceLabel = new Label(); // Initialize totalPriceLabel here
        totalPriceLabel.setTextFill(Color.RED);

        HBox buttonsPane = new HBox(10);
        buttonsPane.setPadding(new Insets(10, 0, 0, 0));
        buttonsPane.setAlignment(Pos.BOTTOM_CENTER);

        Button b1 = new Button("Check Price");
        Button btnbookButton = new Button("Book");
        btnbookButton.setOnAction(event -> {
            Conn c = new Conn();
            try{
                String s1 = c1.getValue();
                String s2 = t1.getText();
                String s3 = l2.getText();
                String s4 = l3.getText();
                String s5 = l4.getText();
                String s6 = totalPriceLabel.getText();

                String q1 = "insert into bookPackage values('"+username+"','"+s1+"', '"+s2+"', '"+s3+"', '"+s4+"', '"+s5+"', '"+s6+"')";
                c.s.executeUpdate(q1);

                showAlert(Alert.AlertType.INFORMATION, "SuccessFull", "Package is Booked Successfully !");
            } catch(Exception ee){
                showAlert(Alert.AlertType.ERROR, "UnSuccessFull", "You have already Booked a package  Please contact with @CustomerSupport");
                System.out.println(ee.getMessage());
            }
        });

        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        b1.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnbookButton.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        b1.setOnAction(event -> updateTotalPrice()); // Add action to update total price when "Check Price" button is clicked

        buttonsPane.getChildren().addAll(b1, btnbookButton, btnExit);

        leftPane.getChildren().addAll(lblName, la2,lusername, lblId, c1, la3, t1, lbl1, l2, lbl2, l3, lbl3, l4, lblDeposite, totalPriceLabel, buttonsPane);

        // Right pane with image
        StackPane rightPane = new StackPane();
        rightPane.setAlignment(Pos.CENTER_LEFT); // Center the image within the stack pane

        ImageView imageView = new ImageView("icons/bookpackage.jpg");
        imageView.setFitWidth(400);
        imageView.setFitHeight(350);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void updateTotalPrice() {
        priceChecked = false; // Reset the flag every time "Check Price" button is clicked

        String selectedPackage = c1.getValue();
        int totalPrice = 0;
        int persons = Integer.parseInt(t1.getText());
        switch (selectedPackage) {
            case "Gold Package":
                totalPrice = 32000 * persons;
                break;
            case "Silver Package":
                totalPrice = 25000 * persons;
                break;
            case "Bronze Package":
                totalPrice = 12000 * persons;
                break;
        }
        totalPriceLabel.setText(String.format("Rs. %d", totalPrice)); // Set the text here
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
