package Tourism;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import java.sql.*;

public class ForgotPassword extends Application {

    private TextField t1, t2, t3, t4, t5;
    private Button b1, b2, b3;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Forgot Password");
        primaryStage.setWidth(850);
        primaryStage.setHeight(400);

        // Left Pane
        GridPane leftPane = new GridPane();
        leftPane.setPadding(new Insets(10));
        leftPane.setHgap(10);
        leftPane.setVgap(10);
        leftPane.setBackground(new Background(new BackgroundFill(Color.rgb(22, 160, 133), CornerRadii.EMPTY, Insets.EMPTY)));

        Label l1 = new Label("Username:");
        l1.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(l1, 0, 0);

        Label l2 = new Label("Name:");
        l2.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(l2, 0, 1);

        Label l3 = new Label("Your Security Question:");
        l3.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(l3, 0, 2);

        Label l4 = new Label("Answer:");
        l4.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(l4, 0, 3);

        Label l5 = new Label("Password:");
        l5.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(l5, 0, 4);

        t1 = new TextField();
        t1.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        t1.setPromptText("Username");
        leftPane.add(t1, 1, 0);

        t2 = new TextField();
        t2.setEditable(false);
        t2.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        t2.setPromptText("Name");
        leftPane.add(t2, 1, 1);

        t3 = new TextField();
        t3.setEditable(false);
        t3.setFont(Font.font("Tahoma", FontWeight.BOLD, 12));
        t3.setPromptText("Your Security Question");
        leftPane.add(t3, 1, 2);

        t4 = new TextField();
        t4.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        t4.setPromptText("Answer");
        leftPane.add(t4, 1, 3);

        t5 = new TextField();
        t5.setEditable(false);
        t5.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        t5.setPromptText("Password");
        leftPane.add(t5, 1, 4);

        b1 = new Button("Search");
        b1.setFont(Font.font("Tahoma", FontWeight.BOLD, 12));
        leftPane.add(b1, 2, 0);
        b1.setOnAction(event -> {
            try{
                Conn con = new Conn();
                String query = "select * from account where username= '" + t1.getText()+"'";

                ResultSet rs = con.s.executeQuery(query);

                while (rs.next()) {
                    t2.setText(rs.getString("name"));
                    t3.setText(rs.getString("Security"));
                }


            } catch (Exception e) {

            };
        });


        b2 = new Button("Retrieve");
        b2.setFont(Font.font("Tahoma", FontWeight.BOLD, 12));
        leftPane.add(b2, 2, 3);
        b2.setOnAction(event -> {
            try {
                Conn con = new Conn();
                String query = "select * from account where answer= '" + t4.getText() + "' AND username= '" + t1.getText() + "'";
                System.out.println("Query: " + query); // Debugging statement
                ResultSet rs = con.s.executeQuery(query);

                if (rs.next()) {
                    t5.setText(rs.getString("Password"));
                    System.out.println("Password retrieved: " + rs.getString("Password")); // Debugging statement
                } else {
                    System.out.println("No matching record found."); // Debugging statement
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        b3 = new Button("Back");
        b3.setFont(Font.font("Tahoma", FontWeight.BOLD, 13));
        leftPane.add(b3, 1, 5);
        b3.setOnAction(event -> {
            new Login().start(primaryStage);
        });

        // Right Pane
        ImageView imageView = new ImageView(new Image("icons/forgotpassword.jpg"));
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);
        Pane rightPane = new Pane(imageView);
        rightPane.setBackground(new Background(new BackgroundFill(Color.rgb(255, 255, 255), CornerRadii.EMPTY, Insets.EMPTY)));

        // Main Layout
        HBox mainLayout = new HBox(leftPane, rightPane);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setSpacing(20);
        mainLayout.setPadding(new Insets(20));

        // Set the background of the main layout with a gradient color
        BackgroundFill backgroundFill = new BackgroundFill(Color.rgb(255, 255, 255), CornerRadii.EMPTY, Insets.EMPTY);
        BackgroundFill backgroundFill2 = new BackgroundFill(Color.rgb(255, 255, 255), CornerRadii.EMPTY, Insets.EMPTY);
        mainLayout.setBackground(new Background(new BackgroundFill[]{backgroundFill, backgroundFill2}));

        Scene scene = new Scene(mainLayout);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
