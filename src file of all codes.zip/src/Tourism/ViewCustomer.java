package Tourism;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewCustomer extends Application {
    private String username;

    // Constructor to accept username
    public ViewCustomer(String username) {
        this.username = username;
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Customer All info");
        primaryStage.setWidth(900);
        primaryStage.setHeight(680);

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffcc00;"); // Changing the background color to a user-attractive color

        // Top Heading
        Label heading = new Label("Customer All Info");
        heading.setFont(Font.font("Arial", FontWeight.BOLD, 24)); // Increase font size
        heading.setTextFill(Color.WHITE);
        BorderPane.setAlignment(heading, Pos.CENTER);
        root.setTop(heading);

        // Left Layout for Labels
        GridPane leftGridPane = new GridPane();
        leftGridPane.setVgap(25);
        leftGridPane.setPadding(new Insets(20));

        Label lblAvailability = new Label("Username");
        Label lblCleanStatus = new Label("Id Type");
        Label lblNewLabel = new Label("Number");
        Label lblNewLabel_1 = new Label("Name");

        // Set label styles
        lblAvailability.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lblCleanStatus.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lblNewLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lblNewLabel_1.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        leftGridPane.add(lblAvailability, 0, 0);
        leftGridPane.add(lblCleanStatus, 0, 1);
        leftGridPane.add(lblNewLabel, 0, 2);
        leftGridPane.add(lblNewLabel_1, 0, 3);

        // Right Layout for Labels
        GridPane rightGridPane = new GridPane();
        rightGridPane.setVgap(25);
        rightGridPane.setPadding(new Insets(20));

        Label lblId = new Label("Gender");
        Label l3 = new Label("Country");
        Label l4 = new Label("Address");
        Label l5 = new Label("Phone");
        Label l6 = new Label("Email");

        // Set label styles
        lblId.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        l3.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        l4.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        l5.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        l6.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        rightGridPane.add(lblId, 0, 0);
        rightGridPane.add(l3, 0, 1);
        rightGridPane.add(l4, 0, 2);
        rightGridPane.add(l5, 0, 3);
        rightGridPane.add(l6, 0, 4);

        // Left Pane for Labels
        Pane leftPane = new Pane(leftGridPane);
        leftPane.setPrefWidth(300);
        leftPane.setStyle("-fx-background-color: #ffcc00;");

        // Right Pane for Labels
        Pane rightPane = new Pane(rightGridPane);
        rightPane.setPrefWidth(300);
        rightPane.setStyle("-fx-background-color: #ffcc00;");

        // Bottom Pane for Images
        Pane bottomPane = new Pane();
        bottomPane.setPrefHeight(200);
        bottomPane.setStyle("-fx-background-color: #f0f0f0;");
        try {
            Conn c = new Conn();
            String query = "SELECT * FROM CustomerData where username = '"+ username+ "'";
            ResultSet resultSet = c.s.executeQuery(query);
            if (resultSet.next()) {
                lblAvailability.setText("Username: " + resultSet.getString("username"));
                lblCleanStatus.setText("Id Type: " + resultSet.getString("idtype"));
                lblNewLabel.setText("Number: " + resultSet.getString("idnumber"));
                lblNewLabel_1.setText("Name: " + resultSet.getString("name"));

                lblId.setText("Gender: " + resultSet.getString("gender"));
                l3.setText("Country: " + resultSet.getString("country"));
                l4.setText("Address: " + resultSet.getString("address"));
                l5.setText("Phone: " + resultSet.getString("phone"));
                l6.setText("Email: " + resultSet.getString("email"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        // Background Images
        Image image1 = new Image("icons/viewall.jpg");
        ImageView imageView1 = new ImageView(image1);
        imageView1.setFitWidth(450);
        imageView1.setFitHeight(150);
        imageView1.setLayoutX(10);
        imageView1.setLayoutY(20);

        Image image2 = new Image("icons/viewall.jpg");
        ImageView imageView2 = new ImageView(image2);
        imageView2.setFitWidth(450);
        imageView2.setFitHeight(150);
        imageView2.setLayoutX(460);
        imageView2.setLayoutY(20);

        bottomPane.getChildren().addAll(imageView1, imageView2);

        // Back Button
        Button backButton = new Button("Back");
        backButton.setPrefWidth(120);
        backButton.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        backButton.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        // Centering the button in the blue area and adding margin
        BorderPane.setAlignment(backButton, Pos.CENTER);
        BorderPane.setMargin(backButton, new Insets(50, 0, 0, 0)); // Move the button down further

        root.setLeft(leftPane);
        root.setRight(rightPane);
        root.setBottom(bottomPane);
        root.setCenter(backButton); // Setting the button to the center

        // Scene
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
