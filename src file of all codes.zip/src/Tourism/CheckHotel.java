package Tourism;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public class CheckHotel extends Application {

    private int currentImageIndex = 0;
    private String[] hotelImages = {
            "/icons/hotel1.jpg",
            "/icons/hotel2.jpg",
            "/icons/hotel3.jpg",
            "/icons/hotel4.jpg",
            "/icons/hotel5.jpg",
            "/icons/hotel6.jpg",
            "/icons/hotel7.jpg",
            "/icons/hotel8.jpg",
            "/icons/hotel9.jpg",
            "/icons/hotel10.jpg"
    };
    private String[] hotelNames = {
            "JW Marriott Hotel",
            "Mandarin Oriental Hotel",
            "Four Seasons Hotel",
            "Radisson Hotel",
            "Classio Hotel",
            "The Bay Club Hotel",
            "Breeze Blows Hotel",
            "Quick Stop Hotel",
            "Happy Mornings Motel",
            "Moss View Hotel"
    };
    private String[] hotelDetails = {
            "5-star luxury hotel with stunning views. Located in " + getRandomLocation() + ". Enjoy the best food in the city!",
            "Luxurious hotel with excellent service. Located in " + getRandomLocation() + ". Perfect for a romantic getaway.",
            "Experience luxury and comfort at its best. Located in " + getRandomLocation() + ". Relax by the poolside.",
            "A comfortable stay with modern amenities. Located in " + getRandomLocation() + ". Best hotel for business travelers.",
            "Affordable accommodation with great facilities. Located in " + getRandomLocation() + ". Close to major attractions.",
            "Enjoy a relaxing stay by the beach. Located in " + getRandomLocation() + ". Try out our spa services!",
            "Perfect for business travelers and tourists alike. Located in " + getRandomLocation() + ". Best meeting rooms in town.",
            "Conveniently located hotel for short stays. Located in " + getRandomLocation() + ". Quick access to transportation.",
            "Cozy motel with friendly staff. Located in " + getRandomLocation() + ". Wake up to the smell of freshly brewed coffee.",
            "Beautiful hotel surrounded by nature. Located in " + getRandomLocation() + ". Take a nature walk in our scenic gardens."
    };
    private Label nameLabel;
    private Label detailsLabel;

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 900, 700, Color.LIGHTBLUE);

        // Right section for displaying image
        StackPane imagePane = new StackPane();
        ImageView imageView = new ImageView();
        imageView.setFitWidth(450);
        imageView.setFitHeight(700);
        imagePane.getChildren().add(imageView);

        // Left section for displaying hotel information
        VBox infoPane = new VBox();
        infoPane.setPrefWidth(450);
        infoPane.setAlignment(Pos.CENTER_LEFT);
        infoPane.setPadding(new Insets(20));
        infoPane.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        nameLabel = new Label();
        nameLabel.setFont(Font.font("Segoe Script", 36));
        nameLabel.setTextFill(Color.DARKBLUE);

        detailsLabel = new Label();
        detailsLabel.setFont(Font.font("Segoe Script", 18));
        detailsLabel.setTextFill(Color.DARKBLUE);
        detailsLabel.setWrapText(true);

        infoPane.getChildren().addAll(nameLabel, detailsLabel);

        root.setCenter(imagePane);
        root.setLeft(infoPane);

        primaryStage.setTitle("Check Hotels");
        primaryStage.setScene(scene);
        primaryStage.show();

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, event -> showNextImage(imageView)),
                new KeyFrame(Duration.seconds(2.8))
        );
        timeline.setCycleCount(hotelImages.length);
        timeline.play();
    }

    private void showNextImage(ImageView imageView) {
        if (currentImageIndex < hotelImages.length) {
            Image image = new Image(getClass().getResourceAsStream(hotelImages[currentImageIndex]));
            imageView.setImage(image);
            nameLabel.setText(hotelNames[currentImageIndex]);
            detailsLabel.setText(hotelDetails[currentImageIndex]);
            currentImageIndex++;
        }
    }

    private static String getRandomLocation() {
        String[] locations = {"Islamabad", "Karachi", "Swabi", "Murree", "Khanpur", "Abbotabad", "Skardu", "Gilgit", "Malam Jaba", "Multan"};
        Random rand = new Random();
        return locations[rand.nextInt(locations.length)];
    }

    public static void main(String[] args) {
        launch(args);
    }
}
