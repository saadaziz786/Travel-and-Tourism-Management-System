package Tourism;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import java.time.LocalTime;

public class Loading extends Application {

    public static void main(String[] args) {
        launch(args);
    }
String username;
    public Loading(String username){
        this.username=username;
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Loading");
        primaryStage.setWidth(600);
        primaryStage.setHeight(400);

        VBox root = new VBox(20);
        root.setStyle("-fx-background-color: #33ccff;");
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        Label headingLabel = new Label("Welcome! Tourism App");
        headingLabel.setFont(Font.font("Trebuchet MS", FontWeight.BOLD, 20));
        headingLabel.setTextFill(Color.rgb(72, 209, 49));

        ProgressBar progressBar = new ProgressBar();
        progressBar.setPrefWidth(300);
        progressBar.setProgress(0.0);

        Label greetingLabel = new Label(getGreeting());
        greetingLabel.setFont(Font.font("Trebuchet MS", FontWeight.NORMAL, 16));
        greetingLabel.setTextFill(Color.WHITE);

        root.getChildren().addAll(headingLabel, progressBar, greetingLabel);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Progress animation
        Timeline timeline = new Timeline();
        KeyValue keyValue = new KeyValue(progressBar.progressProperty(), 1.0);
        KeyFrame keyFrame = new KeyFrame(javafx.util.Duration.seconds(3), keyValue);
        timeline.getKeyFrames().add(keyFrame);
       timeline.setOnFinished(event ->{
           new Dashboard(username).start(new Stage());
           primaryStage.close();
       } );
        timeline.play();
    }

    private String getGreeting() {
        LocalTime currentTime = LocalTime.now();
        if (currentTime.isAfter(LocalTime.of(6, 0)) && currentTime.isBefore(LocalTime.of(12, 0))) {
            return "Welcome Customer, Good morning!";
        } else if (currentTime.isAfter(LocalTime.of(12, 0)) && currentTime.isBefore(LocalTime.of(18, 0))) {
            return "Welcome Customer, Good afternoon!";
        } else {
            return "Welcome Customer, Good evening!";
        }
    }
}
