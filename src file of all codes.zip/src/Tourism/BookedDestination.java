package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookedDestination extends Application {
    String username ;
    public BookedDestination(String username){
        this.username = username;
    }
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 850, 500);

        // Left pane with labels
        VBox leftPane = new VBox(15); // Increased vertical gap to 15
        leftPane.setPadding(new Insets(40, 20, 20, 20));
        leftPane.setStyle("-fx-background-color: blue;");

        Label lblName = new Label("Destination BOOKED DETAILS");
        lblName.setStyle("-fx-font-size: 30; -fx-font-family: 'Yu Mincho'; -fx-text-fill: white;");

        Label lb1 = new Label("Username:");
        lb1.setStyle("-fx-text-fill: white;");

        Label lb2 = new Label("Location:");
        lb2.setStyle("-fx-text-fill: white;");

        Label lb3 = new Label("Total Persons:");
        lb3.setStyle("-fx-text-fill: white;");

        Label lb4 = new Label("Number of Days:");
        lb4.setStyle("-fx-text-fill: white;");

        Label lb5 = new Label("Transport Type:");
        lb5.setStyle("-fx-text-fill: white;");

        Label lb6 = new Label("Food Activity:");
        lb6.setStyle("-fx-text-fill: white;");

        Label lb7 = new Label("ID Type:");
        lb7.setStyle("-fx-text-fill: white;");

        Label lb8 = new Label("ID Number:");
        lb8.setStyle("-fx-text-fill: white;");

        Label lb9 = new Label("Phone:");
        lb9.setStyle("-fx-text-fill: white;");

        Label lb10 = new Label("Total Price:");
        lb10.setStyle("-fx-text-fill: white;");

        Conn c = new Conn();
        try{
            ResultSet resultSet = c.s.executeQuery("select * from Destination where username = '"+username+"'");
            while(resultSet.next()){
                lb1.setText("Username: " + resultSet.getString("username"));
                lb2.setText("Location of Destination: " + resultSet.getString("Location"));
                lb3.setText("Total Persons: " + resultSet.getString("no_persons"));
                lb4.setText("Number of Days: " + resultSet.getString("no_days"));
                lb5.setText("Transport Type: " + resultSet.getString("transport_type"));
                lb6.setText("Tour Activity Pass included : " + resultSet.getString("tour_activity"));
                lb7.setText("ID Type: " + resultSet.getString("idtype"));
                lb8.setText("ID Number: " + resultSet.getString("IDnumber"));
                lb9.setText("Phone: " + resultSet.getString("Phone"));
                lb10.setText("Total Price: " + resultSet.getString("total_price"));
            }
            resultSet.close();
        }catch(SQLException e){}
        // Add space at the bottom for the back button
        VBox.setVgrow(lb10, Priority.ALWAYS);

        leftPane.getChildren().addAll(lblName, lb1, lb2, lb3, lb4, lb5, lb6, lb7, lb8, lb9, lb10);

        // Back button
        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        VBox.setMargin(btnExit, new Insets(20, 0, 0, 0)); // Add margin at the top

        leftPane.getChildren().add(btnExit); // Add button to the left pane

        // Right pane with image
        StackPane rightPane = new StackPane();
        ImageView imageView = new ImageView(new Image("icons/CheckBookedDestination.jpg"));
        imageView.setFitWidth(500);
        imageView.setFitHeight(500);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setTitle("Destination Booked Details");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

