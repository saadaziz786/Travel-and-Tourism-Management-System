package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import jdk.jshell.execution.LoaderDelegate;

import java.sql.ResultSet;

public class Login extends Application {

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 900, 400);
        primaryStage.setTitle("LoginPage");


        // Left Pane
        StackPane leftPane = new StackPane();
        leftPane.setStyle("-fx-background-color: #83c1e9;");
        ImageView imageView = new ImageView(new Image("icons/login.png"));
        imageView.fitWidthProperty().bind(primaryStage.widthProperty().multiply(0.3));
        imageView.fitHeightProperty().bind(primaryStage.heightProperty().multiply(0.8));
        leftPane.getChildren().add(imageView);
        root.setLeft(leftPane);

        // Right Pane
        VBox rightPane = new VBox(20);
        rightPane.setPadding(new Insets(30));
        rightPane.setStyle("-fx-background-color: #f4f4f4;");
        rightPane.setMaxWidth(400);
        rightPane.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));

        Label lblusername = new Label("Username");
        lblusername.setFont(Font.font("Verdana", 16));
        TextField tfusername = new TextField();
        tfusername.setStyle("-fx-background-color: #f8f8f8; -fx-border-color: #ddd;");
        tfusername.setMaxWidth(300);

        Label lblpassword = new Label("Password");
        lblpassword.setFont(Font.font("Verdana", 16));
        PasswordField passwordField = new PasswordField();
        passwordField.setStyle("-fx-background-color: #f8f8f8; -fx-border-color: #ddd;");
        passwordField.setMaxWidth(300);

        Button login = new Button("Login");
        login.setStyle("-fx-background-color: #85c1e9; -fx-text-fill: white;");
        login.setOnAction(event -> {
            try {
                Conn con = new Conn();
                String query = "select * from account where username= '" + tfusername.getText() + "' AND password= '" + passwordField.getText() + "'";
                System.out.println("Query: " + query);
                ResultSet rs = con.s.executeQuery(query);
                String str = tfusername.getText();
                if(rs.next()){

                    new Loading(str).start(primaryStage);




                }
                else {
                    showAlert(Alert.AlertType.ERROR, "Incorrect", "Incorrect Username and Password. Please! Try Again.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        Button signup = new Button("Signup");
        signup.setStyle("-fx-background-color: #85c1e9; -fx-text-fill: white;");
        signup.setOnAction(event -> {
            new Signup().start(primaryStage);
        });
        Button forgetPassword = new Button("Forget Password");
        forgetPassword.setStyle("-fx-background-color: #85c1e9; -fx-text-fill: white;");
        forgetPassword.setOnAction(event -> {
            new ForgotPassword().start(primaryStage);
        });
         Label text = new Label("Trouble in Login...");
        text.setTextFill(Color.RED);


        rightPane.getChildren().addAll(lblusername, tfusername, lblpassword, passwordField,
                login, signup, forgetPassword,text);

        // Center everything
        root.setCenter(rightPane);
        BorderPane.setAlignment(rightPane, Pos.CENTER);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
