package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.sql.*;

public class Destination extends Application {

    String username  ;
    public Destination(String username){
       this.username = username;
    }
    private TextField t1, t2; // Add text field for number of days
    private ChoiceBox<String> c1;
    private ChoiceBox<String> transport; // Add for transport option
    private CheckBox tourIncludedCheckBox; // Add checkbox for tour inclusion
    private Label totalPriceLabel; // Initialize totalPriceLabel here
    private boolean priceChecked = false; // Track whether the price has been checked

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Book Destination");

        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 800, 600);

        // Left pane with labels, text fields, and buttons
        VBox leftPane = new VBox(5); // Decreased vertical gap to 5
        leftPane.setPadding(new Insets(20));
        leftPane.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        Label lblName = new Label("BOOK Destination");
        lblName.setStyle("-fx-font-size: 20; -fx-font-family: 'Yu Mincho';");
        Label la2 = new Label("Username :");
        Label lusername = new Label();
        lusername.setTextFill(Color.WHITE);
        Label lblId = new Label("Select Destination :"); // Changed label text to "Select Hotel"
        Label la3 = new Label("Total Persons");
        Label lbl1 = new Label("ID Type:");
        Label l2 = new Label();
        l2.setTextFill(Color.WHITE);
        Label lbl2 = new Label("Number :");
        Label l3 = new Label();
        l3.setTextFill(Color.WHITE);
        Label lbl3 = new Label("Phone :");
        Label l4 = new Label();
        l4.setTextFill(Color.WHITE);
        Label lblDays = new Label("Number of Days:"); // Added label for number of days
        Label lbltransport = new Label("Transport:"); // Added label for Transport option
        Label lbltour = new Label("Tour Activity Passes :"); // Added label for tour activity inclusion
        Label lblDeposite = new Label("Total Price :");

        c1 = new ChoiceBox<>();
        c1.getItems().addAll("Skardu", "Murree", "Gilgit"); // Changed Destination names
        c1.setValue("Skardu");
        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from CustomerData where username = '"+username+"'");
            while(rs.next()){
                lusername.setText(rs.getString("username"));
                l2.setText(rs.getString("idtype"));
                l3.setText(rs.getString("IDNumber"));
                l4.setText(rs.getString("phone"));
            }
            rs.close();
        } catch(SQLException e){}

        t1 = new TextField();
        t1.setText("1"); // Default to one person

        t2 = new TextField(); // Text field for number of days
        t2.setText("1"); // Default to one day

        transport = new ChoiceBox<>();// Checkbox for AC option
        transport.getItems().addAll("Luxury Class", "Gold Class", "Silver Class");
        transport.setValue("Luxury Class");

        tourIncludedCheckBox = new CheckBox(); // Checkbox for food inclusion

        totalPriceLabel = new Label(); // Initialize totalPriceLabel here
        totalPriceLabel.setTextFill(Color.RED);

        HBox buttonsPane = new HBox(10);
        buttonsPane.setPadding(new Insets(10, 0, 0, 0));
        buttonsPane.setAlignment(Pos.BOTTOM_CENTER);

        Button b1 = new Button("Check Price");
        Button btnbookButton = new Button("Book");
        btnbookButton.setOnAction(event -> {
            Conn c = new Conn();
            try{
                String s1 = c1.getValue();
                String s2 = t1.getText();
                String s3 = t2.getText(); // Get number of days
                String s4 = transport.getValue();
                String s5 = tourIncludedCheckBox.isSelected() ? "Yes" : "No"; // Check if food is included
                String s6 = l2.getText();
                String s7 = l3.getText();
                String s8 = l4.getText();
                String s9 = totalPriceLabel.getText();

                // Calculate total price based on hotel, persons, days, AC, and food inclusion
                int totalPrice = calculateTotalPrice(s1, Integer.parseInt(s2), Integer.parseInt(s3), s4, s5);
                String s10 = String.valueOf(totalPrice);

                String q1 = "INSERT INTO Destination (username, Location, no_persons, no_days, transport_type, tour_activity, idtype, IDnumber, Phone, total_price) VALUES ('" + username + "','" + s1 + "', '" + s2 + "', '" + s3 + "', '" + s4 + "', '" + s5 + "', '" + s6 + "', '" + s7 + "', '" + s8 + "', '" + s10 + "')";

                c.s.executeUpdate(q1);

                showAlert(Alert.AlertType.INFORMATION, "SuccessFull", "Destination is Booked Successfully !");
            } catch(Exception ee){
                showAlert(Alert.AlertType.ERROR, "UnSuccessFull", "A user can booked one Destination at a time !");
                System.out.println(ee.getMessage());
            }
        });

        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        b1.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnbookButton.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        b1.setOnAction(event -> updateTotalPrice()); // Add action to update total price when "Check Price" button is clicked

        buttonsPane.getChildren().addAll(b1, btnbookButton, btnExit);

        leftPane.getChildren().addAll(lblName, la2, lusername, lbl1, l2, lbl2,l3,lbl3,l4, lblId, c1, la3, t1 , lblDays, t2, lbltransport, transport, lbltour, tourIncludedCheckBox, lblDeposite, totalPriceLabel, buttonsPane);

        // Right pane with image
        StackPane rightPane = new StackPane();
        rightPane.setAlignment(Pos.CENTER_LEFT); // Center the image within the stack pane

        ImageView imageView = new ImageView("icons/BookedDestination.jpg"); // Change image path
        imageView.setFitWidth(600);
        imageView.setFitHeight(600);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private int calculateTotalPrice(String hotel, int persons, int days, String transport2, String tourOption) {
        int pricePerDay = 0;
        switch (hotel) {
            case "Skardu":
                pricePerDay = 10000;
                break;
            case "Murree":
                pricePerDay = 15000;
                break;
            case "Gilgit":
                pricePerDay = 20000;
                break;
        }

        int totalPrice = pricePerDay * persons * days; // Price for room per person per day
        int priceperTransport = 0;
        switch (transport2) {
            case "Luxury Class":
                priceperTransport   = 1000;
                break;
            case "Gold Class":
                priceperTransport = 1500;
                break;
            case "Silver Class":
                priceperTransport = 2000;
                break;
        }
        totalPrice += priceperTransport * persons * days;
        if (tourOption.equals("Yes")) {
            totalPrice += 2000 * persons * days; // Additional charge for food per person per day
        }
        return totalPrice;
    }

    private void updateTotalPrice() {
        priceChecked = false; // Reset the flag every time "Check Price" button is clicked

        String selectedHotel = c1.getValue();
        int persons = Integer.parseInt(t1.getText());
        int days = Integer.parseInt(t2.getText()); // Get number of days
        String transport1 =  transport.getValue(); // Check if AC is selected
        String tourinclude = tourIncludedCheckBox.isSelected() ? "Yes" : "No"; // Check if food is included

        int totalPrice = calculateTotalPrice(selectedHotel, persons, days, transport1, tourinclude);
        totalPriceLabel.setText(String.format("Rs. %d", totalPrice)); // Set the text here
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
