package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Payment extends Application {
    String username ;
    public Payment(String username){
        this.username = username;
    }

    @Override
    public void start(Stage primaryStage) {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));

        Text title = new Text("Pay using HBL");
        title.setFill(Color.BLUE);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 40));

        ImageView imageView = new ImageView(new Image("icons/HBL.jpg"));
        imageView.setFitWidth(520);
        imageView.setFitHeight(300);

        Button payButton = new Button("Pay");
        payButton.setOnAction(e -> {
                    new HBL(username).start(new Stage());
                }
        );

        Button backButton = new Button("Back");
        backButton.setOnAction(e ->
        {
            // Handle back button action here
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        root.getChildren().addAll(title, imageView, payButton, backButton);

        Scene scene = new Scene(root, 550, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Payment");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

