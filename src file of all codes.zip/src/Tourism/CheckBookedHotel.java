package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckBookedHotel extends Application {
    String username ;
    public CheckBookedHotel(String username){
       this.username = username;
    }
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 850, 500);

        // Left pane with labels
        VBox leftPane = new VBox(15); // Increased vertical gap to 15
        leftPane.setPadding(new Insets(40, 20, 20, 20));
        leftPane.setStyle("-fx-background-color: blue;");

        Label lblName = new Label("HOTEL BOOKED DETAILS");
        lblName.setStyle("-fx-font-size: 30; -fx-font-family: 'Yu Mincho'; -fx-text-fill: white;");

        Label lb1 = new Label("Username:");
        lb1.setStyle("-fx-text-fill: white;");

        Label lb2 = new Label("Hotel Name:");
        lb2.setStyle("-fx-text-fill: white;");

        Label lb3 = new Label("Total Persons:");
        lb3.setStyle("-fx-text-fill: white;");

        Label lb4 = new Label("Number of Days:");
        lb4.setStyle("-fx-text-fill: white;");

        Label lb5 = new Label("AC Required:");
        lb5.setStyle("-fx-text-fill: white;");

        Label lb6 = new Label("Food Included:");
        lb6.setStyle("-fx-text-fill: white;");

        Label lb7 = new Label("ID Type:");
        lb7.setStyle("-fx-text-fill: white;");

        Label lb8 = new Label("ID Number:");
        lb8.setStyle("-fx-text-fill: white;");

        Label lb9 = new Label("Phone:");
        lb9.setStyle("-fx-text-fill: white;");

        Label lb10 = new Label("Total Price:");
        lb10.setStyle("-fx-text-fill: white;");

        Conn c = new Conn();
        try{
            ResultSet resultSet = c.s.executeQuery("select * from BOOKHOTEL where username = '"+username+"'");
            while(resultSet.next()){
                lb1.setText("Username: " + resultSet.getString("username"));
                lb2.setText("Hotel Name: " + resultSet.getString("NameofHotel"));
                lb3.setText("Total Persons: " + resultSet.getString("Totalpersons"));
                lb4.setText("Number of Days: " + resultSet.getString("Days"));
                lb5.setText("AC Required: " + resultSet.getString("AC"));
                lb6.setText("Food Included: " + resultSet.getString("Food"));
                lb7.setText("ID Type: " + resultSet.getString("idType"));
                lb8.setText("ID Number: " + resultSet.getString("IDNumber"));
                lb9.setText("Phone: " + resultSet.getString("phone"));
                lb10.setText("Total Price: " + resultSet.getString("TotalPrice"));
            }

            resultSet.close();
        }catch(SQLException e){}
        // Add space at the bottom for the back button
        VBox.setVgrow(lb10, Priority.ALWAYS);

        leftPane.getChildren().addAll(lblName, lb1, lb2, lb3, lb4, lb5, lb6, lb7, lb8, lb9, lb10);

        // Back button
        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        VBox.setMargin(btnExit, new Insets(20, 0, 0, 0)); // Add margin at the top

        leftPane.getChildren().add(btnExit); // Add button to the left pane

        // Right pane with image
        StackPane rightPane = new StackPane();
        ImageView imageView = new ImageView(new Image("icons/bookedDetails.jpg"));
        imageView.setFitWidth(500);
        imageView.setFitHeight(500);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setTitle("Hotel Booked Details");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
