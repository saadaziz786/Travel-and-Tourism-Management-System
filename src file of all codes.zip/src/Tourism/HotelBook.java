package Tourism;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.sql.*;

public class HotelBook extends Application {

    String username ;
    public HotelBook(String username){
       this.username = username;
   }
    private TextField t1, t2; // Add text field for number of days
    private ChoiceBox<String> c1;
    private CheckBox acCheckBox; // Add checkbox for AC option
    private CheckBox foodIncludedCheckBox; // Add checkbox for food inclusion
    private Label totalPriceLabel; // Initialize totalPriceLabel here
    private boolean priceChecked = false; // Track whether the price has been checked

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Book Hotel");

        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 800, 600);

        // Left pane with labels, text fields, and buttons
        VBox leftPane = new VBox(5); // Decreased vertical gap to 5
        leftPane.setPadding(new Insets(20));
        leftPane.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        Label lblName = new Label("BOOK HOTEL");
        lblName.setStyle("-fx-font-size: 20; -fx-font-family: 'Yu Mincho';");
        Label la2 = new Label("Username :");
        Label lusername = new Label();
        lusername.setTextFill(Color.WHITE);
        Label lblId = new Label("Select Hotel :"); // Changed label text to "Select Hotel"
        Label la3 = new Label("Total Persons");
        Label lbl1 = new Label("ID Type:");
        Label l2 = new Label();
        l2.setTextFill(Color.WHITE);
        Label lbl2 = new Label("Number :");
        Label l3 = new Label();
        l3.setTextFill(Color.WHITE);
        Label lbl3 = new Label("Phone :");
        Label l4 = new Label();
        l4.setTextFill(Color.WHITE);
        Label lblDays = new Label("Number of Days:"); // Added label for number of days
        Label lblAC = new Label("AC Required:"); // Added label for AC option
        Label lblFood = new Label("Food Included:"); // Added label for food inclusion
        Label lblDeposite = new Label("Total Price :");

        c1 = new ChoiceBox<>();
        c1.getItems().addAll("Taj Hotel", "Serena Hotel", "Luxus Hotel"); // Changed hotel names
        c1.setValue("Taj Hotel"); // Default to Taj Hotel
        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from CustomerData where username = '"+username+"'");
            while(rs.next()){
                lusername.setText(rs.getString("username"));
                l2.setText(rs.getString("idtype"));
                l3.setText(rs.getString("IDNumber"));
                l4.setText(rs.getString("phone"));
            }
            rs.close();
        } catch(SQLException e){}

        t1 = new TextField();
        t1.setText("1"); // Default to one person

        t2 = new TextField(); // Text field for number of days
        t2.setText("1"); // Default to one day

        acCheckBox = new CheckBox(); // Checkbox for AC option

        foodIncludedCheckBox = new CheckBox(); // Checkbox for food inclusion

        totalPriceLabel = new Label(); // Initialize totalPriceLabel here
        totalPriceLabel.setTextFill(Color.RED);

        HBox buttonsPane = new HBox(10);
        buttonsPane.setPadding(new Insets(10, 0, 0, 0));
        buttonsPane.setAlignment(Pos.BOTTOM_CENTER);

        Button b1 = new Button("Check Price");
        Button btnbookButton = new Button("Book");
        btnbookButton.setOnAction(event -> {
            Conn c = new Conn();
            try{
                String s1 = c1.getValue();
                String s2 = t1.getText();
                String s3 = t2.getText(); // Get number of days
                String s4 = acCheckBox.isSelected() ? "Yes" : "No"; // Check if AC is selected
                String s5 = foodIncludedCheckBox.isSelected() ? "Yes" : "No"; // Check if food is included
                String s6 = l2.getText();
                String s7 = l3.getText();
                String s8 = l4.getText();
                String s9 = totalPriceLabel.getText();

                // Calculate total price based on hotel, persons, days, AC, and food inclusion
                int totalPrice = calculateTotalPrice(s1, Integer.parseInt(s2), Integer.parseInt(s3), s4, s5);
                String s10 = String.valueOf(totalPrice);

                String q1 = "INSERT INTO bookHotel (username, NameofHotel, Totalpersons, Days, AC, FOOD, idType, IDNumber, phone, TotalPrice) VALUES ('" + username + "','" + s1 + "', '" + s2 + "', '" + s3 + "', '" + s4 + "', '" + s5 + "', '" + s6 + "', '" + s7 + "', '" + s8 + "', '" + s10 + "')";
                c.s.executeUpdate(q1);

                showAlert(Alert.AlertType.INFORMATION, "SuccessFull", "Hotel is Booked Successfully !");
            } catch(Exception ee){
                showAlert(Alert.AlertType.ERROR, "UnSuccessFull", "A user can booked one hotel at a time !");
                System.out.println(ee.getMessage());
            }
        });

        Button btnExit = new Button("Back");
        btnExit.setOnAction(event -> {
            new Dashboard(username).start(new Stage());
            primaryStage.close();
        });

        b1.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnbookButton.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        btnExit.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        b1.setOnAction(event -> updateTotalPrice()); // Add action to update total price when "Check Price" button is clicked

        buttonsPane.getChildren().addAll(b1, btnbookButton, btnExit);

        leftPane.getChildren().addAll(lblName, la2, lusername, lbl1, l2, lbl2,l3,lbl3,l4, lblId, c1, la3, t1 , lblDays, t2, lblAC, acCheckBox, lblFood, foodIncludedCheckBox, lblDeposite, totalPriceLabel, buttonsPane);

        // Right pane with image
        StackPane rightPane = new StackPane();
        rightPane.setAlignment(Pos.CENTER_LEFT); // Center the image within the stack pane

        ImageView imageView = new ImageView("icons/book.jpg"); // Change image path
        imageView.setFitWidth(600);
        imageView.setFitHeight(600);
        rightPane.getChildren().add(imageView);

        borderPane.setLeft(leftPane);
        borderPane.setRight(rightPane);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private int calculateTotalPrice(String hotel, int persons, int days, String acOption, String foodOption) {
        int pricePerDay = 0;
        switch (hotel) {
            case "Taj Hotel":
                pricePerDay = 10000;
                break;
            case "Serena Hotel":
                pricePerDay = 15000;
                break;
            case "Luxus Hotel":
                pricePerDay = 20000;
                break;
        }

        int totalPrice = pricePerDay * persons * days; // Price for room per person per day
        if (acOption.equals("Yes")) {
            totalPrice += 2000 * persons * days; // Additional charge for AC per person per day
        }
        if (foodOption.equals("Yes")) {
            totalPrice += 2000 * persons * days; // Additional charge for food per person per day
        }
        return totalPrice;
    }

    private void updateTotalPrice() {
        priceChecked = false; // Reset the flag every time "Check Price" button is clicked

        String selectedHotel = c1.getValue();
        int persons = Integer.parseInt(t1.getText());
        int days = Integer.parseInt(t2.getText()); // Get number of days
        String acOption = acCheckBox.isSelected() ? "Yes" : "No"; // Check if AC is selected
        String foodOption = foodIncludedCheckBox.isSelected() ? "Yes" : "No"; // Check if food is included

        int totalPrice = calculateTotalPrice(selectedHotel, persons, days, acOption, foodOption);
        totalPriceLabel.setText(String.format("Rs. %d", totalPrice)); // Set the text here
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
