package Tourism;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public class Destinations extends Application {

    private int currentImageIndex = 0;
    private String[] desImages = {
            "/icons/dest1.jpg",
            "/icons/dest2.jpg",
            "/icons/dest3.jpeg",
            "/icons/dest4.jpeg",
            "/icons/dest5.jpeg",
            "/icons/dest6.jpg",
            "/icons/dest7.jpeg",
            "/icons/dest8.jpg",
            "/icons/dest9.jpg",
            "/icons/dest10.jpeg"
    };
    private String[] desnames = {
            "Skardu",
            "Hunza Valley",
            "Fairy Meadows",
            "Swat Valley",
            "Naran Kaghan",
            "Murree",
            "Attabad Lake",
            "Neelum Valley",
            "Khunjerab Pass",
            "Shangrila Resort"
    };
    private String[] desdetails = {
            "Where Mountains Touch the Sky",
            "Discover the Jewel of the Himalayas",
            "Step into a Fairytale World",
            "Nature's Symphony in Green",
            "Where Adventure Meets Serenity",
            "Escape to the Cool Embrace of the Hills",
            "Turquoise Tranquility Amidst Majestic Mountains",
            "Journey into the Heart of Paradise",
            "Where the World Meets at the Roof of the World",
            "Find Your Bliss in Nature's Wonderland"
    };
    private Label nameLabel;
    private Label detailsLabel;

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 900, 700, Color.LIGHTBLUE);

        // Right section for displaying image
        StackPane imagePane = new StackPane();
        ImageView imageView = new ImageView();
        imageView.setFitWidth(450);
        imageView.setFitHeight(700);
        imagePane.getChildren().add(imageView);

        // Left section for displaying hotel information
        VBox infoPane = new VBox();
        infoPane.setPrefWidth(450);
        infoPane.setAlignment(Pos.CENTER_LEFT);
        infoPane.setPadding(new Insets(20));
        infoPane.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        nameLabel = new Label();
        nameLabel.setFont(Font.font("Segoe Script", 36));
        nameLabel.setTextFill(Color.DARKBLUE);

        detailsLabel = new Label();
        detailsLabel.setFont(Font.font("Segoe Script", 18));
        detailsLabel.setTextFill(Color.DARKBLUE);
        detailsLabel.setWrapText(true);

        infoPane.getChildren().addAll(nameLabel, detailsLabel);

        root.setCenter(imagePane);
        root.setLeft(infoPane);

        primaryStage.setTitle("Check Destinations");
        primaryStage.setScene(scene);
        primaryStage.show();

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, event -> showNextImage(imageView)),
                new KeyFrame(Duration.seconds(2.8))
        );
        timeline.setCycleCount(desImages.length);
        timeline.play();
    }

    private void showNextImage(ImageView imageView) {
        if (currentImageIndex < desImages.length) {
            Image image = new Image(getClass().getResourceAsStream(desImages[currentImageIndex]));
            imageView.setImage(image);
            nameLabel.setText(desnames[currentImageIndex]);
            detailsLabel.setText(desdetails[currentImageIndex]);
            currentImageIndex++;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
